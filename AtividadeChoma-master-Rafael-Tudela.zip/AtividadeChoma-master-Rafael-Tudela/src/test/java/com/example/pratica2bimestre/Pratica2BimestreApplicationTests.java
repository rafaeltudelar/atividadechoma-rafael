package com.example.pratica2bimestre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pratica2BimestreApplicationTests {

    @Test
    void contextLoads() {
    }

}
