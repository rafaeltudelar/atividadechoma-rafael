package com.example.pratica2bimestre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pratica2BimestreApplication {

    public static void main(String[] args) {
        SpringApplication.run(Pratica2BimestreApplication.class, args);
    }

}
